package com.studysphere;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private TextView pageTitle, pageSubtitle;
    private final String[] pages = {"Home", "Study", "Habits", "Focus", "Profile"};

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pageTitle = findViewById(R.id.pageTitle);
        pageSubtitle = findViewById(R.id.pageSubtitle);

        int[] ids = {R.id.navHome, R.id.navStudy, R.id.navHabits, R.id.navFocus, R.id.navProfile};
        String[] subtitles = {
            "Your learning day, thoughtfully organized.",
            "Track AP ECET 2027 CSE preparation.",
            "Build steady routines one day at a time.",
            "Make room for focused study sessions.",
            "Your StudySphere preferences and tools."
        };
        for (int i = 0; i < ids.length; i++) {
            final int index = i;
            findViewById(ids[i]).setOnClickListener(v -> showPage(index, subtitles[index]));
        }
        showPage(0, subtitles[0]);
        findViewById(R.id.startFocusButton).setOnClickListener(v ->
            Toast.makeText(this, "Focus timer module is the next implementation step.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.openSyllabusButton).setOnClickListener(v -> showPage(1, subtitles[1]));
    }

    private void showPage(int index, String subtitle) {
        pageTitle.setText(pages[index]);
        pageSubtitle.setText(subtitle);
        int[] ids = {R.id.navHome, R.id.navStudy, R.id.navHabits, R.id.navFocus, R.id.navProfile};
        for (int i = 0; i < ids.length; i++) {
            MaterialButton b = findViewById(ids[i]);
            b.setAlpha(i == index ? 1f : 0.62f);
        }
    }
}
