# StudySphere Android starter

This is the first runnable project foundation for StudySphere, using Java, XML, AndroidX, Material Components and Room.

## Open in Android Studio
1. Extract the ZIP.
2. Android Studio: **File > Open** and select the `StudySphere` folder.
3. Allow Gradle sync to finish.
4. Run on an Android device or emulator.

## Current implementation
- Lavender/purple Material-style foundation
- Home dashboard starter
- Five-section bottom navigation shell
- Quick actions for Study and Focus

## Important
This is a starter foundation, not yet the complete feature-complete app. The database-backed syllabus, MCQs, mock tests, planner, habit tracking, timer, analytics, PIN lock, backup/restore, AI service and six Android home-screen widgets still need their individual implementations and testing. AP ECET 2027 official syllabus/content should be updated when released. The app does not include unverified question banks or an exam date.

## Build APK
Use **Build > Build Bundle(s) / APK(s) > Build APK(s)** in Android Studio. The generated debug APK is usually under `app/build/outputs/apk/debug/`.
